//Name: Dylan Ford
//Date: Dec 10, 2019
//Description: contains an attribute for the head of a graph's adjacency matrix
#pragma once
#include "GraphNode.hpp"

class AdjList {
public: 
	GraphNode* head_;
};